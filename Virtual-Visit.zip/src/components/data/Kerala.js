const kerala=[
{
    id: 1,
    image: "https://www.trawell.in/admin/images/thumbs/129720830Kottayam_Main_thumb.jpg",
    name: "Kottayam",
    title: "Kochi",
    quote:"Kottayam is a city located in central Kerala and is also the administrative capital of Kottayam district. It is one of the well known Kerala tourist places. About 63 km from Kochi and 155 km from Trivandrum, it is among the most prominent places to visit near Kochi."
},
{
    id: 1,
    image: "https://www.trawell.in/admin/images/thumbs/12972087Thrissur_Main_thumb.jpg",
    name: "Thrissur",
    title: "Kochi",
    quote:"Thrissur, also known as Trichur, is one of the famous places of pilgrimage in Kerala, and among the must include places in Kerala tour packages. Situated about 81 km from Kochi, and 279 km from Trivandrum, this is one of the ideal weekend getaways from Kochi & Coimbatore."
},
{
    id: 1,
    image: "https://www.trawell.in/admin/images/thumbs/148645591Sabarimala_Main_thumb.jpg",
    name: "Sabarimala",
    title: "Pathanamthitta",
    quote:"Sabarimala is one of the most famous places of pilgrimage in Kerala. Situated about 70 km from Pathanamthitta, this temple is one of the oldest temples in India, with a history of more than 5000 years old.Regarded as one of the popular places to visit in Kerala, Sabarimala temple is dedicated to Lord Ayyappan, and is believed that Lord Parasurama installed the idol of Ayyappa here."
},

]
export default kerala;